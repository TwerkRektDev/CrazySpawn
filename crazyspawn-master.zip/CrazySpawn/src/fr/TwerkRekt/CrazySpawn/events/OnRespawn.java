package fr.TwerkRekt.CrazySpawn.events;

import fr.TwerkRekt.CrazySpawn.Main;
import fr.TwerkRekt.CrazySpawn.locations.LocationManager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class OnRespawn implements Listener {
  Main plugin;
  
  public OnRespawn(Main instance) {
    this.plugin = instance;
  }
  
  @EventHandler
  public void onPlayerRespawn(PlayerRespawnEvent e) {
    final Player p = e.getPlayer();
    final LocationManager spawnCoords = LocationManager.getManager();
    if (this.plugin.getConfig().getBoolean("Respawn-At-Spawn"))
      (new BukkitRunnable() {
          public void run() {
            if (!OnRespawn.this.plugin.getConfig().getBoolean("Override-Bedspawn-On-Respawn")) {
              if (p.getBedSpawnLocation() != null) {
                p.teleport(p.getBedSpawnLocation());
              } else if (OnRespawn.this.plugin.getConfig().getConfigurationSection("spawn") != null) {
                World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
                double x = spawnCoords.getConfig().getDouble("spawn.x");
                double y = spawnCoords.getConfig().getDouble("spawn.y");
                double z = spawnCoords.getConfig().getDouble("spawn.z");
                float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
                float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
                Location loc = new Location(w, x, y, z, yaw, pitch);
                p.teleport(loc);
              } 
            } else {
              World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
              double x = spawnCoords.getConfig().getDouble("spawn.x");
              double y = spawnCoords.getConfig().getDouble("spawn.y");
              double z = spawnCoords.getConfig().getDouble("spawn.z");
              float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
              float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
              Location loc = new Location(w, x, y, z, yaw, pitch);
              p.teleport(loc);
            } 
          }
        }).runTaskLater((Plugin)this.plugin, 1L); 
  }
}
