package fr.TwerkRekt.CrazySpawn.events;

import fr.TwerkRekt.CrazySpawn.Main;
import fr.TwerkRekt.CrazySpawn.locations.LocationManager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class OnJoin implements Listener {
  Main plugin;
  
  public OnJoin(Main instance) {
    this.plugin = instance;
  }
  
  @EventHandler
  public void onJoin(PlayerJoinEvent e) {
    final Player p = e.getPlayer();
    final LocationManager spawnCoords = LocationManager.getManager();
    if (!p.hasPlayedBefore()) {
      if (this.plugin.getConfig().getBoolean("On-First-Join-Spawn")) {
        if (spawnCoords.getConfig().getConfigurationSection("firstspawn") != null) {
          (new BukkitRunnable() {
              public void run() {
                World w = Bukkit.getServer()
                  .getWorld(spawnCoords.getConfig().getString("firstspawn.world"));
                double x = spawnCoords.getConfig().getDouble("firstspawn.x");
                double y = spawnCoords.getConfig().getDouble("firstspawn.y");
                double z = spawnCoords.getConfig().getDouble("firstspawn.z");
                float yaw = (float)spawnCoords.getConfig().getDouble("firstspawn.yaw");
                float pitch = (float)spawnCoords.getConfig().getDouble("firstspawn.pitch");
                Location loc = new Location(w, x, y, z, yaw, pitch);
                p.teleport(loc);
              }
            }).runTaskLater((Plugin)this.plugin, 20L);
        } else if (spawnCoords.getConfig().getConfigurationSection("spawn") != null) {
          (new BukkitRunnable() {
              public void run() {
                World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
                double x = spawnCoords.getConfig().getDouble("spawn.x");
                double y = spawnCoords.getConfig().getDouble("spawn.y");
                double z = spawnCoords.getConfig().getDouble("spawn.z");
                float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
                float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
                Location loc = new Location(w, x, y, z, yaw, pitch);
                p.teleport(loc);
              }
            }).runTaskLater((Plugin)this.plugin, 20L);
        } 
      } else if (spawnCoords.getConfig().getConfigurationSection("spawn") != null) {
        (new BukkitRunnable() {
            public void run() {
              World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
              double x = spawnCoords.getConfig().getDouble("spawn.x");
              double y = spawnCoords.getConfig().getDouble("spawn.y");
              double z = spawnCoords.getConfig().getDouble("spawn.z");
              float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
              float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
              Location loc = new Location(w, x, y, z, yaw, pitch);
              p.teleport(loc);
            }
          }).runTaskLater((Plugin)this.plugin, 20L);
      } 
    } else if (spawnCoords.getConfig().getConfigurationSection("spawn") != null && 
      this.plugin.getConfig().getBoolean("On-Join-Spawn")) {
      (new BukkitRunnable() {
          public void run() {
            World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
            double x = spawnCoords.getConfig().getDouble("spawn.x");
            double y = spawnCoords.getConfig().getDouble("spawn.y");
            double z = spawnCoords.getConfig().getDouble("spawn.z");
            float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
            float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
            Location loc = new Location(w, x, y, z, yaw, pitch);
            p.teleport(loc);
          }
        }).runTaskLater((Plugin)this.plugin, 20L);
    } 
  }
}
