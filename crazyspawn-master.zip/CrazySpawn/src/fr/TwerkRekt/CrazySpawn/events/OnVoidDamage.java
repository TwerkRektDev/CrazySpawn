package fr.TwerkRekt.CrazySpawn.events;

import fr.TwerkRekt.CrazySpawn.Main;
import fr.TwerkRekt.CrazySpawn.locations.LocationManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class OnVoidDamage implements Listener {
  Main plugin;
  
  public OnVoidDamage(Main instance) {
    this.plugin = instance;
  }
  
  @EventHandler
  public void onDamage(EntityDamageEvent e) {
    LocationManager spawnCoords = LocationManager.getManager();
    if (this.plugin.getConfig().getBoolean("Void-To-Spawn.Enabled") && e.getEntity() instanceof Player) {
      Player p = (Player)e.getEntity();
      if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
        World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
        double x = spawnCoords.getConfig().getDouble("spawn.x");
        double y = spawnCoords.getConfig().getDouble("spawn.y");
        double z = spawnCoords.getConfig().getDouble("spawn.z");
        float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
        float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
        Location loc = new Location(w, x, y, z, yaw, pitch);
        p.teleport(loc);
        e.setCancelled(true);
      } 
      if (e.getCause().equals(EntityDamageEvent.DamageCause.FALL)) {
        e.setCancelled(true);
        return;
      } 
      if (this.plugin.getConfig().getBoolean("Void-To-Spawn.Enabled-Message")) {
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
              this.plugin.getConfig().getString("Void-To-Spawn.Message")));
        return;
      } 
    } 
  }
}
