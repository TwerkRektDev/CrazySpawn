package fr.TwerkRekt.CrazySpawn.locations;

import java.io.File;
import java.io.IOException;
import fr.TwerkRekt.CrazySpawn.Main;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;

public class LocationManager implements Listener {
  private Main plugin = (Main)Main.getPlugin(Main.class);
  
  public File location;
  
  public YamlConfiguration spawnCoords;
  
  private static LocationManager manager = new LocationManager();
  
  private LocationManager() {}
  
  public LocationManager(Main mainclass) {}
  
  public static LocationManager getManager() {
    return manager;
  }
  
  public void setupFiles() {
    this.location = new File(this.plugin.getDataFolder(), "locations.yml");
    if (!this.location.exists()) {
      this.location.getParentFile().mkdirs();
      this.plugin.saveResource("locations.yml", false);
    } 
    this.spawnCoords = new YamlConfiguration();
    try {
      this.spawnCoords.load(this.location);
    } catch (IOException|org.bukkit.configuration.InvalidConfigurationException e) {
      e.printStackTrace();
    } 
  }
  
  public FileConfiguration getConfig() {
    return (FileConfiguration)this.spawnCoords;
  }
  
  public void saveConfig() {
    try {
      this.spawnCoords.save(this.location);
    } catch (IOException iOException) {}
  }
  
  public void reloadConfig() {
    this.spawnCoords = YamlConfiguration.loadConfiguration(this.location);
  }
}