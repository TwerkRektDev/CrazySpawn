package fr.TwerkRekt.CrazySpawn;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import fr.TwerkRekt.CrazySpawn.events.OnJoin;
import fr.TwerkRekt.CrazySpawn.events.OnRespawn;
import fr.TwerkRekt.CrazySpawn.events.OnVoidDamage;
import fr.TwerkRekt.CrazySpawn.locations.LocationManager;

public class Main extends JavaPlugin implements Listener, CommandExecutor {
  public Map<Player, BukkitTask> tasks = new HashMap<>();
  
  public Main plugin;
  
  public File location;
  
  public FileConfiguration spawnCoords;
  
  public String MainConfig;
  
  public void onEnable() {
    Bukkit.getPluginManager().registerEvents(this, (Plugin)this);
    Bukkit.getPluginManager().registerEvents((Listener)new OnJoin(this), (Plugin)this);
    Bukkit.getPluginManager().registerEvents((Listener)new OnRespawn(this), (Plugin)this);
    Bukkit.getPluginManager().registerEvents((Listener)new OnVoidDamage(this), (Plugin)this);
    Bukkit.getPluginManager().registerEvents((Listener)new LocationManager(this), (Plugin)this);
    LocationManager.getManager().setupFiles();
    LocationManager.getManager().reloadConfig();
    saveDefaultConfig();
    configMain();
    getLogger().info("�e------------------------------");
    getLogger().info("�aCrazySpawn plugin loaded");
    getLogger().info("�aAuthor: TwerkRekt");
    getLogger().info("�aVersion: 1.0");
    getLogger().info("�aDownload link: link need to add it");
    getLogger().info("�e------------------------------");
  }
  
  public void onDisable() {
	    getLogger().info("�e------------------------------");
	    getLogger().info("�cCrazySpawn plugin unloaded");
	    getLogger().info("�cAuthor: TwerkRekt");
	    getLogger().info("�cVersion: 1.0");
	    getLogger().info("�cDownload link: link need to add it");
	    getLogger().info("�e------------------------------");
  }
  
  public void configMain() {
    File config = new File(getDataFolder(), "config.yml");
    this.MainConfig = config.getPath();
    if (!config.exists()) {
      getConfig().options().copyDefaults(true);
      saveConfig();
    } 
  }
  
  public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
    if (!(sender instanceof Player)) {
      getServer().getConsoleSender().sendMessage("�cOnly players can execute commands.");
      return true;
    } 
    final Player p = (Player)sender;
    LocationManager spawnCoords = LocationManager.getManager();
    if (!p.hasPermission("spawn.spawn")) {
      p.sendMessage(ChatColor.translateAlternateColorCodes('&', getConfig().getString("No-Permission-Message")));
      return true;
    } 
    if (alias.equalsIgnoreCase("spawn"))
      if (args.length == 0) {
        if (spawnCoords.getConfig().getConfigurationSection("spawn") == null) {
          p.sendMessage(
              ChatColor.translateAlternateColorCodes('&', getConfig().getString("No-Spawn-Message")));
          return true;
        } 
        if (getConfig().getBoolean("Teleport-Message.Enabled"))
          p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                getConfig().getString("Teleport-Message.Message"))); 
        World w = Bukkit.getServer().getWorld(spawnCoords.getConfig().getString("spawn.world"));
        double x = spawnCoords.getConfig().getDouble("spawn.x");
        double y = spawnCoords.getConfig().getDouble("spawn.y");
        double z = spawnCoords.getConfig().getDouble("spawn.z");
        float yaw = (float)spawnCoords.getConfig().getDouble("spawn.yaw");
        float pitch = (float)spawnCoords.getConfig().getDouble("spawn.pitch");
        final Location loc = new Location(w, x, y, z, yaw, pitch);
        if (!p.hasPermission("spawn.bypass")) {
          if (!this.tasks.containsKey(p)) {
            this.tasks.put(p, (new BukkitRunnable() {
                  public void run() {
                    p.teleport(loc);
                    if (Main.this.getConfig().getBoolean("Spawn-Message.Enabled"))
                      p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                            Main.this.getConfig().getString("Spawn-Message.Message"))); 
                    if (Main.this.getConfig().getBoolean("Spawn-Effect.Enabled")) {
                      p.getWorld().playEffect(p.getLocation(), 
                          Effect.valueOf(Main.this.getConfig().getString("Spawn-Effect.Effect-Name")), 
                          0);
                      p.getWorld().playEffect(p.getLocation(), 
                          Effect.valueOf(Main.this.getConfig().getString("Spawn-Effect.Effect-Name")), 
                          0);
                      p.getWorld().playEffect(p.getLocation(), 
                          Effect.valueOf(Main.this.getConfig().getString("Spawn-Effect.Effect-Name")), 
                          0);
                    } 
                    if (Main.this.getConfig().getBoolean("Spawn-Sound.Enabled"))
                      p.getWorld().playSound(p.getLocation(), 
                          Sound.valueOf(Main.this.getConfig().getString("Spawn-Sound.Sound-Name")), 
                          1.0F, 1.0F); 
                    Main.this.tasks.remove(p);
                  }
                }).runTaskLater((Plugin)this, 20L * getConfig().getInt("Cooldown")));
            return true;
          } 
        } else {
          p.teleport(loc);
          if (getConfig().getBoolean("Spawn-Message.Enabled"))
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                  getConfig().getString("Spawn-Message.Message"))); 
          if (getConfig().getBoolean("Spawn-Effect.Enabled")) {
            p.getWorld().playEffect(p.getLocation(), 
                Effect.valueOf(getConfig().getString("Spawn-Effect.Effect-Name")), 
                0);
            p.getWorld().playEffect(p.getLocation(), 
                Effect.valueOf(getConfig().getString("Spawn-Effect.Effect-Name")), 
                0);
            p.getWorld().playEffect(p.getLocation(), 
                Effect.valueOf(getConfig().getString("Spawn-Effect.Effect-Name")), 
                0);
          } 
          if (getConfig().getBoolean("Spawn-Sound.Enabled"))
            p.getWorld().playSound(p.getLocation(), 
                Sound.valueOf(getConfig().getString("Spawn-Sound.Sound-Name")), 
                1.0F, 1.0F); 
        } 
      } else if (args.length == 1) {
        if (args[0].equalsIgnoreCase("set")) {
          if (!p.hasPermission("spawn.set")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                  getConfig().getString("No-Permission-Message")));
            return true;
          } 
          spawnCoords.getConfig().set("spawn.world", p.getLocation().getWorld().getName());
          spawnCoords.getConfig().set("spawn.x", Double.valueOf(p.getLocation().getX()));
          spawnCoords.getConfig().set("spawn.y", Double.valueOf(p.getLocation().getY()));
          spawnCoords.getConfig().set("spawn.z", Double.valueOf(p.getLocation().getZ()));
          spawnCoords.getConfig().set("spawn.yaw", Float.valueOf(p.getLocation().getYaw()));
          spawnCoords.getConfig().set("spawn.pitch", Float.valueOf(p.getLocation().getPitch()));
          spawnCoords.saveConfig();
          p.sendMessage(
              ChatColor.translateAlternateColorCodes('&', getConfig().getString("Set-Spawn-Message")));
          return true;
        } 
        if (args[0].equals("setfirst")) {
          if (!p.hasPermission("spawn.setfirst")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                  getConfig().getString("No-Permission-Message")));
            return true;
          } 
          spawnCoords.getConfig().set("firstspawn.world", p.getLocation().getWorld().getName());
          spawnCoords.getConfig().set("firstspawn.x", Double.valueOf(p.getLocation().getX()));
          spawnCoords.getConfig().set("firstspawn.y", Double.valueOf(p.getLocation().getY()));
          spawnCoords.getConfig().set("firstspawn.z", Double.valueOf(p.getLocation().getZ()));
          spawnCoords.getConfig().set("firstspawn.yaw", Float.valueOf(p.getLocation().getYaw()));
          spawnCoords.getConfig().set("firstspawn.pitch", Float.valueOf(p.getLocation().getPitch()));
          spawnCoords.saveConfig();
          p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                getConfig().getString("Set-First-Join-Spawn-Message")));
          return true;
        } 
        if (args[0].equalsIgnoreCase("reload")) {
          if (!p.hasPermission("spawn.reload")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                  getConfig().getString("No-Permission-Message")));
            return true;
          } 
          reloadConfig();
          p.sendMessage(ChatColor.translateAlternateColorCodes('&', getConfig().getString("Reload-Message")));
        } else if (args[0].equalsIgnoreCase("help")) {
          if (!p.hasPermission("spawn.help")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                  getConfig().getString("No-Permission-Message")));
            return true;
          } 
          p.sendMessage("�e-------------------- �2CrazySpawn �e--------------------");
          p.sendMessage("�e/spawn �f- �eTeleport to the spawn.");
          p.sendMessage("�e/spawn set �f- �eSet the spawn location.");
          p.sendMessage("�e/spawn reload �f- �eReload the config.");
          p.sendMessage("�e/spawn help �f- �eSee the help page.");
          p.sendMessage("�e-------------------- �2CrazySpawn �e--------------------");
        } 
      }  
    return true;
  }
  
  @EventHandler
  public void onPlayerMove(PlayerMoveEvent e) {
    Player p = e.getPlayer();
    if (e.getFrom().getBlockX() != e.getTo().getBlockX() || e.getFrom().getBlockY() != e.getTo().getBlockY() || 
      e.getFrom().getBlockZ() != e.getTo().getBlockZ()) {
      BukkitTask task = this.tasks.get(p);
      if (getConfig().getBoolean("Cancel-On-Move.Enabled") && task != null) {
        if (getConfig().getBoolean("Cancel-On-Move.Enable-Message"))
          p.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                getConfig().getString("Cancel-On-Move.Message"))); 
        task.cancel();
        this.tasks.remove(p);
      } 
    } 
  }
}
